import React from "react";
import { Trash2, FolderInput, X } from "lucide-react";

export default function BulkActionBar({ count, onMove, onDelete, onCancel }) {
  if (!count) return null;
  return (
    <div className="flex items-center gap-3 px-4 py-3 rounded-2xl border border-primary/30 bg-primary/5 shadow-[0_10px_40px_-15px_rgba(37,99,235,0.3)]">
      <span className="w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_rgba(37,99,235,0.8)]" />
      <span className="text-sm font-semibold text-accent-foreground">{count} selected</span>
      <div className="flex-1" />
      <button onClick={onMove} className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg border border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground transition-colors">
        <FolderInput className="w-4 h-4" /> Move
      </button>
      <button onClick={onDelete} className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg border border-destructive/30 text-destructive hover:bg-destructive hover:text-destructive-foreground transition-colors">
        <Trash2 className="w-4 h-4" /> Delete
      </button>
      <button onClick={onCancel} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}