import React, { useState } from "react";
import { Terminal, ArrowRight } from "lucide-react";

export default function CommandBar({ onRun }) {
  const [value, setValue] = useState("");
  const [running, setRunning] = useState(false);

  const submit = async () => {
    const text = value.trim();
    if (!text || running) return;
    setRunning(true);
    try {
      await onRun(text);
    } finally {
      setRunning(false);
      setValue("");
    }
  };

  return (
    <div className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card shadow-sm focus-within:ring-2 focus-within:ring-primary/30 focus-within:border-primary/40 transition-all">
      <Terminal className="w-4 h-4 text-muted-foreground shrink-0" />
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && submit()}
        placeholder='Try "move x to Archive" or "download update-browserslist-db"'
        disabled={running}
        className="flex-1 min-w-0 bg-transparent text-sm focus:outline-none placeholder:text-muted-foreground/60"
      />
      <button
        onClick={submit}
        disabled={running || !value.trim()}
        className="p-1 rounded-full text-muted-foreground hover:text-primary disabled:opacity-30 transition-colors shrink-0"
        title="Run"
      >
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}
