import React from "react";
import { ArrowUpDown, List, LayoutGrid } from "lucide-react";

export default function SortBar({ sort, setSort, view, setView }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-2.5 py-1.5 shadow-sm">
        <ArrowUpDown className="w-4 h-4 text-muted-foreground" />
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="text-sm bg-transparent focus:outline-none cursor-pointer pr-1"
        >
          <option value="name">Name</option>
          <option value="date">Date modified</option>
          <option value="size">Size</option>
        </select>
      </div>
      <div className="flex items-center rounded-lg border border-border bg-card overflow-hidden shadow-sm">
        <button
          onClick={() => setView("list")}
          className={`p-2 transition-colors ${view === "list" ? "bg-primary text-primary-foreground" : "hover:bg-accent text-muted-foreground"}`}
          title="List view"
        >
          <List className="w-4 h-4" />
        </button>
        <button
          onClick={() => setView("grid")}
          className={`p-2 transition-colors ${view === "grid" ? "bg-primary text-primary-foreground" : "hover:bg-accent text-muted-foreground"}`}
          title="Grid view"
        >
          <LayoutGrid className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}