import React from "react";
import { Folder, FileText, FileImage, File, Download } from "lucide-react";

function iconFor(item) {
  if (item.type === "folder") return Folder;
  if ((item.mime_type || "").startsWith("image/")) return FileImage;
  if ((item.mime_type || "").startsWith("text/")) return FileText;
  return File;
}

export default function FileRow({ item, selectMode, selected, onToggle, onOpen, onRename, onMove, onDelete, onPreview, onDownload }) {
  const Icon = iconFor(item);
  const isSel = selected.has(item.id);
  return (
    <div
      className={`group flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${isSel ? "bg-primary/5 ring-1 ring-primary/40 shadow-[0_8px_30px_-12px_rgba(37,99,235,0.25)]" : "hover:bg-accent/70"}`}
      onClick={() => (item.type === "folder" ? onOpen(item) : onPreview(item))}
    >
      {selectMode && (
        <input
          type="checkbox"
          checked={isSel}
          onClick={(e) => e.stopPropagation()}
          onChange={() => onToggle(item.id)}
          className="shrink-0 accent-[hsl(221,83%,53%)]"
        />
      )}
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${item.type === "folder" ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"}`}>
        <Icon className="w-4.5 h-4.5" />
      </div>
      <span className="flex-1 truncate text-sm font-medium">{item.name}</span>
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        {item.type === "file" && (
          <button
            onClick={(e) => { e.stopPropagation(); onDownload(item); }}
            className="p-1.5 rounded-lg hover:bg-card text-muted-foreground hover:text-primary transition-colors"
            title="Download"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onRename(item); }}
          className="px-2.5 py-1 text-xs font-medium rounded-lg hover:bg-card text-muted-foreground hover:text-foreground transition-colors"
        >
          Rename
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onMove(item); }}
          className="px-2.5 py-1 text-xs font-medium rounded-lg hover:bg-card text-muted-foreground hover:text-foreground transition-colors"
        >
          Move
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onDelete(item); }}
          className="px-2.5 py-1 text-xs font-medium rounded-lg hover:bg-card text-destructive transition-colors"
        >
          Delete
        </button>
      </div>
    </div>
  );
}