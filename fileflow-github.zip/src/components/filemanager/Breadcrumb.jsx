import React from "react";
import { ChevronRight, Home } from "lucide-react";

export default function Breadcrumb({ path, onNavigate }) {
  return (
    <nav className="flex items-center gap-1 flex-wrap text-sm">
      <button
        onClick={() => onNavigate(null)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-muted-foreground hover:text-primary hover:bg-accent transition-colors"
      >
        <Home className="w-4 h-4" />
        <span className="font-medium">Home</span>
      </button>
      {path.map((item, idx) => (
        <React.Fragment key={item.id}>
          <ChevronRight className="w-4 h-4 text-muted-foreground/40" />
          <button
            onClick={() => onNavigate(item.id)}
            className={`px-2.5 py-1.5 rounded-lg transition-colors ${
              idx === path.length - 1
                ? "text-foreground font-semibold bg-accent"
                : "text-muted-foreground hover:text-primary hover:bg-accent"
            }`}
          >
            {item.name}
          </button>
        </React.Fragment>
      ))}
    </nav>
  );
}