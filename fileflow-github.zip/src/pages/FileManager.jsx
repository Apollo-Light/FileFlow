import React, { useState, useMemo, useRef } from "react";
import { FolderPlus, FilePlus, Upload, CheckSquare, Square, HardDrive, Unplug } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import Breadcrumb from "@/components/filemanager/Breadcrumb";
import FileList from "@/components/filemanager/FileList";
import FilePreview from "@/components/filemanager/FilePreview";
import RenameDialog from "@/components/filemanager/RenameDialog";
import MoveDialog from "@/components/filemanager/MoveDialog";
import NewFolderDialog from "@/components/filemanager/NewFolderDialog";
import NewFileDialog from "@/components/filemanager/NewFileDialog";
import ConfirmDialog from "@/components/filemanager/ConfirmDialog";
import SearchBar from "@/components/filemanager/SearchBar";
import BulkActionBar from "@/components/filemanager/BulkActionBar";
import SortBar from "@/components/filemanager/SortBar";
import CommandBar from "@/components/filemanager/CommandBar";
import { parseCommand, findFolderTarget, findItemByName } from "@/lib/commandParser";
import {
  isLocalFsSupported,
  pickLocalFolder,
  buildLocalTree,
  createLocalFolder,
  createLocalTextFile,
  writeLocalFileBytes,
  writeLocalBytesAtPath,
  readLocalFile,
  deleteLocalEntry,
  renameLocalEntry,
  moveLocalEntry,
} from "@/lib/localFs";
import { downloadUrl, fetchNpmPackageFiles } from "@/lib/downloader";

export default function FileManager() {
  const { toast } = useToast();
  const [allItems, setAllItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentId, setCurrentId] = useState("");
  const [preview, setPreview] = useState(null);
  const [renameTarget, setRenameTarget] = useState(null);
  const [moveTarget, setMoveTarget] = useState(null);
  const [bulkMoveOpen, setBulkMoveOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [newFileOpen, setNewFileOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [sort, setSort] = useState("name");
  const [view, setView] = useState("list");

  // FileFlow works directly against a real folder on this device, granted
  // via the browser's File System Access API — no backend, no login.
  const [connected, setConnected] = useState(false);
  const [localFolderName, setLocalFolderName] = useState("");
  const [connecting, setConnecting] = useState(false);
  const rootHandleRef = useRef(null);
  const localHandlesRef = useRef(new Map());

  const loadAll = async () => {
    if (!rootHandleRef.current) { setLoading(false); return; }
    setLoading(true);
    try {
      const { items, handles } = await buildLocalTree(rootHandleRef.current);
      localHandlesRef.current = handles;
      setAllItems(items);
    } catch {
      toast({ title: "Failed to read local folder", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const connectLocalFolder = async () => {
    if (!isLocalFsSupported()) {
      toast({ title: "Not supported in this browser", description: "Try Chrome or Edge for local folder access.", variant: "destructive" });
      return;
    }
    setConnecting(true);
    try {
      const handle = await pickLocalFolder(); // triggers the native OS permission prompt
      if (!handle) return; // user cancelled
      rootHandleRef.current = handle;
      setLocalFolderName(handle.name);
      setConnected(true);
      setCurrentId("");
      setLoading(true);
      const { items, handles } = await buildLocalTree(handle);
      localHandlesRef.current = handles;
      setAllItems(items);
      toast({ title: `Connected to "${handle.name}"` });
    } catch (err) {
      if (err?.name !== "AbortError") {
        toast({ title: "Couldn't access that folder", description: "Permission was denied or the request failed.", variant: "destructive" });
      }
    } finally {
      setConnecting(false);
      setLoading(false);
    }
  };

  const disconnectLocalFolder = () => {
    rootHandleRef.current = null;
    localHandlesRef.current = new Map();
    setLocalFolderName("");
    setConnected(false);
    setAllItems([]);
    setCurrentId("");
    setSelectMode(false);
    setSelected(new Set());
  };

  const sortedItems = useMemo(() => {
    const items = allItems
      .filter((i) => (i.parent_id || "") === currentId)
      .sort((a, b) => {
        if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
        let cmp = 0;
        if (sort === "name") cmp = a.name.localeCompare(b.name);
        else if (sort === "date") cmp = new Date(b.updated_date) - new Date(a.updated_date);
        else if (sort === "size") cmp = (b.size || 0) - (a.size || 0);
        return cmp;
      });
    return items;
  }, [allItems, currentId, sort]);

  const allFolders = useMemo(() => allItems.filter((i) => i.type === "folder"), [allItems]);

  const breadcrumb = useMemo(() => {
    const path = [];
    let id = currentId;
    while (id) {
      const folder = allItems.find((i) => i.id === id);
      if (!folder) break;
      path.unshift(folder);
      id = folder.parent_id || "";
    }
    return path;
  }, [allItems, currentId]);

  const openFolder = (folder) => setCurrentId(folder.id);
  const navigateTo = (id) => { setCurrentId(id || ""); setSelectMode(false); setSelected(new Set()); };

  const toggleSelect = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const exitSelect = () => { setSelectMode(false); setSelected(new Set()); };

  const createFolder = async (name) => {
    try {
      await createLocalFolder(localHandlesRef.current, rootHandleRef.current, currentId, name);
      toast({ title: `Created "${name}"` });
      loadAll();
    } catch { toast({ title: "Failed to create folder", variant: "destructive" }); }
  };

  const createFile = async (name, content) => {
    try {
      await createLocalTextFile(localHandlesRef.current, rootHandleRef.current, currentId, name, content);
      toast({ title: `Created "${name}"` });
      loadAll();
    } catch { toast({ title: "Failed to create file", variant: "destructive" }); }
  };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const bytes = await file.arrayBuffer();
      await writeLocalFileBytes(localHandlesRef.current, rootHandleRef.current, currentId, file.name, bytes);
      toast({ title: `Uploaded "${file.name}"` });
      loadAll();
    } catch { toast({ title: "Upload failed", variant: "destructive" }); }
    finally { setUploading(false); e.target.value = ""; }
  };

  const downloadFile = async (item) => {
    try {
      const file = await readLocalFile(localHandlesRef.current, item.id);
      if (!file) throw new Error("not found");
      const url = URL.createObjectURL(file);
      const a = document.createElement("a");
      a.href = url;
      a.download = item.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast({ title: `Downloaded "${item.name}"` });
    } catch { toast({ title: "Download failed", variant: "destructive" }); }
  };

  const performRename = async (item, newName) => {
    await renameLocalEntry(localHandlesRef.current, rootHandleRef.current, item.id, newName);
  };

  const performMove = async (item, destId) => {
    await moveLocalEntry(localHandlesRef.current, rootHandleRef.current, item.id, destId);
  };

  const renameItem = async (newName) => {
    try {
      await performRename(renameTarget, newName);
      toast({ title: `Renamed to "${newName}"` });
      loadAll();
    } catch { toast({ title: "Rename failed", variant: "destructive" }); }
  };

  const moveItem = async (destId) => {
    try {
      await performMove(moveTarget, destId);
      toast({ title: "Moved successfully" });
      loadAll();
    } catch { toast({ title: "Move failed", variant: "destructive" }); }
  };

  const bulkMove = async (destId) => {
    try {
      const ids = [...selected];
      for (const id of ids) await moveLocalEntry(localHandlesRef.current, rootHandleRef.current, id, destId);
      toast({ title: `Moved ${ids.length} items` });
      exitSelect();
      loadAll();
    } catch { toast({ title: "Bulk move failed", variant: "destructive" }); }
  };

  const deleteItem = async (item) => {
    try {
      await deleteLocalEntry(localHandlesRef.current, rootHandleRef.current, item.id);
      if (currentId === item.id) setCurrentId(item.parent_id || "");
      loadAll();
    } catch { toast({ title: "Delete failed", variant: "destructive" }); }
  };

  const confirmDelete = async (item) => {
    await deleteItem(item);
    toast({ title: `Deleted "${item.name}"` });
  };

  const openPreview = async (item) => {
    if (item.type !== "file") { setPreview(item); return; }
    try {
      const file = await readLocalFile(localHandlesRef.current, item.id);
      if (!file) { setPreview(item); return; }
      if ((item.mime_type || "").startsWith("image/")) {
        setPreview({ ...item, file_url: URL.createObjectURL(file) });
      } else {
        setPreview({ ...item, content: await file.text() });
      }
    } catch {
      setPreview(item);
    }
  };

  const bulkDelete = async () => {
    try {
      const ids = [...selected];
      for (const id of ids) {
        const item = allItems.find((i) => i.id === id);
        if (item) await deleteItem(item);
      }
      toast({ title: `Deleted ${ids.length} items` });
      exitSelect();
      loadAll();
    } catch { toast({ title: "Bulk delete failed", variant: "destructive" }); }
  };

  const saveDownloadedFile = async (name, bytes) => {
    await writeLocalFileBytes(localHandlesRef.current, rootHandleRef.current, currentId, name, bytes);
  };

  const saveDownloadedPackageFile = async (pkgName, relPath, bytes) => {
    await writeLocalBytesAtPath(localHandlesRef.current, rootHandleRef.current, currentId, `${pkgName}/${relPath}`, bytes);
  };

  // Fetches bytes only — never executes anything from the download.
  const runDownload = async (raw) => {
    const isUrl = /^https?:\/\//i.test(raw) || /^www\./i.test(raw);
    try {
      if (isUrl) {
        const url = raw.startsWith("http") ? raw : `https://${raw}`;
        const { name, bytes } = await downloadUrl(url);
        await saveDownloadedFile(name, bytes);
        toast({ title: `Downloaded "${name}"` });
      } else {
        toast({ title: `Fetching ${raw}\u2026` });
        const { name, version, files } = await fetchNpmPackageFiles(raw);
        for (const f of files) {
          await saveDownloadedPackageFile(name, f.path, f.bytes);
        }
        toast({ title: `Downloaded ${name}@${version} \u2014 ${files.length} files, nothing was run` });
      }
      loadAll();
    } catch (err) {
      toast({ title: "Download failed", description: err.message, variant: "destructive" });
    }
  };

  // Command bar: parses plain-English input into one of the same safe file
  // operations the buttons above call. Never touches a real shell — it only
  // ever reads the already-loaded item list and calls createFolder/createFile/
  // performRename/performMove/deleteItem, exactly like clicking the UI would.
  const runCommand = async (text) => {
    const cmd = parseCommand(text);

    if (cmd.action === "noop") return;

    if (cmd.action === "unknown") {
      toast({ title: "Didn't understand that", description: `Try things like "move X to Y", "rename X to Y", "delete X", "create folder X", "download <url or package>".`, variant: "destructive" });
      return;
    }

    if (cmd.action === "download") {
      await runDownload(cmd.subject);
      return;
    }

    if (cmd.action === "create_folder") {
      await createFolder(cmd.subject);
      return;
    }

    if (cmd.action === "create_file") {
      await createFile(cmd.subject, "");
      return;
    }

    if (cmd.action === "open") {
      const folder = findFolderTarget(allItems, cmd.subject) || findItemByName(allItems, cmd.subject, currentId);
      if (!folder) { toast({ title: `Couldn't find "${cmd.subject}"`, variant: "destructive" }); return; }
      if (folder.type === "folder" || folder.id === "") navigateTo(folder.id);
      else openPreview(folder);
      return;
    }

    if (cmd.action === "delete") {
      const item = findItemByName(allItems, cmd.subject, currentId);
      if (!item) { toast({ title: `Couldn't find "${cmd.subject}"`, variant: "destructive" }); return; }
      await deleteItem(item);
      toast({ title: `Deleted "${item.name}"` });
      return;
    }

    if (cmd.action === "rename") {
      const item = findItemByName(allItems, cmd.subject, currentId);
      if (!item) { toast({ title: `Couldn't find "${cmd.subject}"`, variant: "destructive" }); return; }
      try {
        await performRename(item, cmd.target);
        toast({ title: `Renamed to "${cmd.target}"` });
        loadAll();
      } catch { toast({ title: "Rename failed", variant: "destructive" }); }
      return;
    }

    if (cmd.action === "move") {
      const item = findItemByName(allItems, cmd.subject, currentId);
      if (!item) { toast({ title: `Couldn't find "${cmd.subject}"`, variant: "destructive" }); return; }
      const dest = findFolderTarget(allItems, cmd.target);
      if (!dest) { toast({ title: `Couldn't find folder "${cmd.target}"`, variant: "destructive" }); return; }
      try {
        await performMove(item, dest.id);
        toast({ title: `Moved "${item.name}" to ${dest.id ? dest.name : "Home"}` });
        loadAll();
      } catch { toast({ title: "Move failed", variant: "destructive" }); }
      return;
    }
  };

  if (!connected) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="max-w-md w-full text-center">
          <h1 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-foreground leading-none mb-3">FileFlow</h1>
          <p className="text-sm text-muted-foreground mb-8">
            Connect a folder on this device to start browsing, editing, and downloading files — nothing leaves your computer.
          </p>
          <button
            onClick={connectLocalFolder}
            disabled={connecting}
            className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium rounded-full bg-primary text-primary-foreground shadow-[0_8px_30px_-12px_rgba(37,99,235,0.5)] hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            <HardDrive className="w-4 h-4" /> {connecting ? "Connecting..." : "Open Local Folder"}
          </button>
          {!isLocalFsSupported() && (
            <p className="text-xs text-destructive mt-4">Your browser doesn't support this. Try Chrome or Edge.</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-6 py-10 md:py-14">
        <header className="mb-8 flex items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-foreground leading-none">FileFlow</h1>
            <p className="text-sm text-muted-foreground mt-2">
              Browsing local folder "{localFolderName}" — nothing leaves your computer.
            </p>
          </div>
          <span className="hidden sm:flex items-center gap-2 text-xs font-medium text-muted-foreground bg-card border border-border rounded-full px-3 py-1.5 shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(37,99,235,0.8)]" />
            {sortedItems.length} items
          </span>
        </header>

        <div className="mb-4">
          <CommandBar onRun={runCommand} />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 mb-4">
          <SearchBar allItems={allItems} onNavigate={(id) => navigateTo(id)} />
          <SortBar sort={sort} setSort={setSort} view={view} setView={setView} />
          <button
            onClick={() => { setSelectMode((s) => !s); if (selectMode) setSelected(new Set()); }}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-full border transition-all shadow-sm ${selectMode ? "bg-primary text-primary-foreground border-primary shadow-[0_8px_30px_-12px_rgba(37,99,235,0.5)]" : "border-border bg-card hover:bg-accent"}`}
          >
            {selectMode ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
            Select
          </button>
          <div className="flex-1" />
          <button
            onClick={disconnectLocalFolder}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-full border border-border bg-card shadow-sm hover:bg-accent transition-colors"
            title="Disconnect this folder"
          >
            <Unplug className="w-4 h-4" /> Disconnect
          </button>
        </div>

        {selectMode && (
          <div className="mb-4">
            <BulkActionBar
              count={selected.size}
              onMove={() => setBulkMoveOpen(true)}
              onDelete={() => setBulkDeleteOpen(true)}
              onCancel={exitSelect}
            />
          </div>
        )}

        <div className="flex items-center justify-between gap-3 mb-5 pb-5 border-b border-border">
          <Breadcrumb path={breadcrumb} onNavigate={navigateTo} />
          <div className="flex items-center gap-2">
            <button onClick={() => setNewFolderOpen(true)} className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-full border border-border bg-card shadow-sm hover:bg-accent transition-colors">
              <FolderPlus className="w-4 h-4" /> Folder
            </button>
            <button onClick={() => setNewFileOpen(true)} className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-full border border-border bg-card shadow-sm hover:bg-accent transition-colors">
              <FilePlus className="w-4 h-4" /> File
            </button>
            <label className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-full bg-primary text-primary-foreground shadow-[0_8px_30px_-12px_rgba(37,99,235,0.5)] hover:opacity-90 transition-opacity cursor-pointer">
              <Upload className="w-4 h-4" /> {uploading ? "Uploading..." : "Upload"}
              <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
            </label>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card shadow-[0_20px_60px_-25px_rgba(37,99,235,0.18)] min-h-[420px]">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="w-6 h-6 border-2 border-secondary border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <FileList
              items={sortedItems}
              view={view}
              selectMode={selectMode}
              selected={selected}
              onToggle={toggleSelect}
              onOpen={openFolder}
              onRename={setRenameTarget}
              onMove={setMoveTarget}
              onDelete={setDeleteTarget}
              onPreview={openPreview}
              onDownload={downloadFile}
            />
          )}
        </div>
      </div>

      <FilePreview file={preview} onClose={() => setPreview(null)} />
      <RenameDialog open={!!renameTarget} item={renameTarget} onConfirm={renameItem} onClose={() => setRenameTarget(null)} />
      <MoveDialog open={!!moveTarget} title={`Move "${moveTarget?.name}"`} folders={allFolders} excludeIds={moveTarget ? [moveTarget.id] : []} onConfirm={moveItem} onClose={() => setMoveTarget(null)} />
      <MoveDialog open={bulkMoveOpen} title={`Move ${selected.size} items`} folders={allFolders} excludeIds={[...selected]} onConfirm={bulkMove} onClose={() => setBulkMoveOpen(false)} />
      <NewFolderDialog open={newFolderOpen} onConfirm={createFolder} onClose={() => setNewFolderOpen(false)} />
      <NewFileDialog open={newFileOpen} onConfirm={createFile} onClose={() => setNewFileOpen(false)} />
      <ConfirmDialog open={!!deleteTarget} item={deleteTarget} onConfirm={confirmDelete} onClose={() => setDeleteTarget(null)} />
      <ConfirmDialog open={bulkDeleteOpen} item={{ name: `${selected.size} items`, type: "file" }} onConfirm={bulkDelete} onClose={() => setBulkDeleteOpen(false)} />
    </div>
  );
}
