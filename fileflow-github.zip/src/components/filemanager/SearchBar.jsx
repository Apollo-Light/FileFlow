import React, { useState, useMemo, useRef, useEffect } from "react";
import { Search, Folder, FileText, FileImage, File as FileIcon } from "lucide-react";

function iconFor(item) {
  if (item.type === "folder") return Folder;
  if ((item.mime_type || "").startsWith("image/")) return FileImage;
  if ((item.mime_type || "").startsWith("text/")) return FileText;
  return FileIcon;
}

export default function SearchBar({ allItems, onNavigate }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return allItems.filter((i) => i.name.toLowerCase().includes(q)).slice(0, 8);
  }, [query, allItems]);

  const pick = (item) => {
    onNavigate(item.parent_id || "", item.id);
    setQuery("");
    setOpen(false);
  };

  return (
    <div className="relative flex-1 min-w-[200px] max-w-xs" ref={ref}>
      <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
      <input
        value={query}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder="Search files & folders..."
        className="w-full pl-10 pr-4 py-2 text-sm rounded-full border border-border bg-card shadow-sm placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/40 transition-all"
      />
      {open && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-2xl shadow-[0_20px_50px_-15px_rgba(37,99,235,0.25)] z-50 overflow-hidden">
          {results.map((item) => {
            const Icon = iconFor(item);
            return (
              <button
                key={item.id}
                onClick={() => pick(item)}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-accent text-left transition-colors"
              >
                <Icon className={`w-4 h-4 shrink-0 ${item.type === "folder" ? "text-primary" : "text-muted-foreground"}`} />
                <span className="text-sm truncate flex-1 font-medium">{item.name}</span>
                <span className="text-xs text-muted-foreground capitalize">{item.type}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}