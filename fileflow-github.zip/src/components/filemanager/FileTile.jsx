import React from "react";
import { Folder, FileText, FileImage, File, Download, Pencil, FolderInput, Trash2 } from "lucide-react";

function iconFor(item) {
  if (item.type === "folder") return Folder;
  if ((item.mime_type || "").startsWith("image/")) return FileImage;
  if ((item.mime_type || "").startsWith("text/")) return FileText;
  return File;
}

export default function FileTile({ item, selectMode, selected, onToggle, onOpen, onRename, onMove, onDelete, onPreview, onDownload }) {
  const Icon = iconFor(item);
  const isSel = selected.has(item.id);
  return (
    <div
      className={`group relative flex flex-col items-center gap-3 p-5 rounded-2xl border cursor-pointer transition-all hover:-translate-y-0.5 ${isSel ? "border-primary ring-2 ring-primary/30 bg-primary/5 shadow-[0_16px_40px_-12px_rgba(37,99,235,0.3)]" : "border-border bg-card shadow-[0_10px_30px_-12px_rgba(15,23,42,0.1)] hover:shadow-[0_16px_40px_-12px_rgba(37,99,235,0.22)]"}`}
      onClick={() => (item.type === "folder" ? onOpen(item) : onPreview(item))}
    >
      {selectMode && (
        <input
          type="checkbox"
          checked={isSel}
          onClick={(e) => e.stopPropagation()}
          onChange={() => onToggle(item.id)}
          className="absolute top-3 left-3 accent-[hsl(221,83%,53%)]"
        />
      )}
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${item.type === "folder" ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"}`}>
        <Icon className="w-7 h-7" />
      </div>
      <span className="text-xs font-medium text-center break-all line-clamp-2">{item.name}</span>
      <div className="absolute top-3 right-3 flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
        {item.type === "file" && (
          <button onClick={(e) => { e.stopPropagation(); onDownload(item); }} className="p-1.5 rounded-lg hover:bg-card text-muted-foreground hover:text-primary" title="Download">
            <Download className="w-3.5 h-3.5" />
          </button>
        )}
        <button onClick={(e) => { e.stopPropagation(); onRename(item); }} className="p-1.5 rounded-lg hover:bg-card text-muted-foreground hover:text-foreground" title="Rename">
          <Pencil className="w-3.5 h-3.5" />
        </button>
        <button onClick={(e) => { e.stopPropagation(); onMove(item); }} className="p-1.5 rounded-lg hover:bg-card text-muted-foreground hover:text-foreground" title="Move">
          <FolderInput className="w-3.5 h-3.5" />
        </button>
        <button onClick={(e) => { e.stopPropagation(); onDelete(item); }} className="p-1.5 rounded-lg hover:bg-card text-destructive" title="Delete">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}