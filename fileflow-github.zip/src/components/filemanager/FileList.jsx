import React from "react";
import FileRow from "./FileRow";
import FileTile from "./FileTile";

export default function FileList({ items, view, selectMode, selected, onToggle, onOpen, onRename, onMove, onDelete, onPreview, onDownload }) {
  if (!items.length) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center mb-4">
          <span className="text-2xl">📂</span>
        </div>
        <p className="text-sm font-medium text-foreground">This folder is empty</p>
        <p className="text-xs text-muted-foreground mt-1">Create a folder or upload a file to get started</p>
      </div>
    );
  }

  if (view === "grid") {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 p-3">
        {items.map((item) => (
          <FileTile
            key={item.id}
            item={item}
            selectMode={selectMode}
            selected={selected}
            onToggle={onToggle}
            onOpen={onOpen}
            onRename={onRename}
            onMove={onMove}
            onDelete={onDelete}
            onPreview={onPreview}
            onDownload={onDownload}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1 p-3">
      {items.map((item) => (
        <FileRow
          key={item.id}
          item={item}
          selectMode={selectMode}
          selected={selected}
          onToggle={onToggle}
          onOpen={onOpen}
          onRename={onRename}
          onMove={onMove}
          onDelete={onDelete}
          onPreview={onPreview}
          onDownload={onDownload}
        />
      ))}
    </div>
  );
}