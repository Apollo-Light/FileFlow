import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function MoveDialog({ open, title, folders, excludeIds = [], onConfirm, onClose }) {
  const [selected, setSelected] = useState("");

  useEffect(() => {
    if (open) setSelected("");
  }, [open]);

  const exclude = new Set(excludeIds);
  const targets = folders.filter((f) => !exclude.has(f.id) && !exclude.has(f.parent_id || ""));

  const submit = () => {
    onConfirm(selected);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{title || "Move item"}</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">Choose a destination folder:</p>
        <select
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
        >
          <option value="">— Home (root) —</option>
          {targets.map((f) => (
            <option key={f.id} value={f.id}>{f.name}</option>
          ))}
        </select>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={submit}>Move</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}