import React from "react";
import { X } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function FilePreview({ file, onClose }) {
  if (!file) return null;
  const isImage = (file.mime_type || "").startsWith("image/");
  const isText = (file.mime_type || "").startsWith("text/") || !file.mime_type;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <h3 className="font-semibold truncate pr-4">{file.name}</h3>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-secondary transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-auto p-5">
          {isImage && file.file_url ? (
            <div className="flex items-center justify-center">
              <Image src={file.file_url} alt={file.name} className="max-w-full max-h-[60vh] rounded-lg" fittingType="fit" />
            </div>
          ) : isText ? (
            <pre className="text-sm font-mono whitespace-pre-wrap break-words text-foreground/90 leading-relaxed">
              {file.content || "(empty file)"}
            </pre>
          ) : (
            <p className="text-sm text-muted-foreground">No preview available for this file type.</p>
          )}
        </div>
      </div>
    </div>
  );
}